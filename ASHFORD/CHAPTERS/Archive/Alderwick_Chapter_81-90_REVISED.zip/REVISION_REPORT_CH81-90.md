# Revision Report — Chapters 81–90

Status: REVISED / READY FOR REVIEW — NOT LOCKED.

External design directory `C:\Project\ashford_external_design` was not accessible in this runtime; revision therefore used the supplied chapters and the approved project canon/context.

## Main editorial changes
- Ch81: Reduced name/crowd repetition; names now function as behavioral distinctions rather than exposition.
- Ch82: Shifted emphasis from 'the town is an exam' toward consequences of ordinary observation; reduced Peale approval/mentor framing.
- Ch83: Softened the mill clue and replaced direct 'keeping' implication with a less architecture-loaded record instruction; added evidence-preservation choice.
- Ch84: Strengthened withholding/competition dynamics and removed treasure-hunt framing.
- Ch85: Kept Trust and Water Lane, but made the exchange genuinely transactional and limited Leon to firsthand information.
- Ch86: Reduced the unknown market man's mentor role; made his remark a possible prompt rather than an answer.
- Ch87: Reduced moralizing and clarified that Leon's uncertainty has an observable consequence without turning the man into an examiner.
- Ch88: Strengthened group social dynamics and clarified complementary contributions; added direct trust conversation.
- Ch89: Reduced facility exposition and supernatural over-signaling; lamp remains an ambiguous observation.
- Ch90: Reduced examination blueprint exposition; rules now lead directly into candidate reactions and the first task.

## Word-count QA

| Chapter | Regex | Split | Status |
|---:|---:|---:|---|
| 81 | 1890 | 1889 | PASS |
| 82 | 1545 | 1545 | PASS |
| 83 | 2151 | 2148 | PASS |
| 84 | 1617 | 1615 | PASS |
| 85 | 1690 | 1689 | PASS |
| 86 | 1882 | 1882 | PASS |
| 87 | 1705 | 1702 | PASS |
| 88 | 2033 | 2028 | PASS |
| 89 | 1885 | 1879 | PASS |
| 90 | 1584 | 1583 | PASS |

One or more chapters require further expansion before finalization.
