# Alderwick — Revision Report Chapters 61–70

**Status: REVISED / READY FOR REVIEW — not LOCKED**

This pass is deliberately conservative: plot, canon, chapter order, and the approved Vale progression are preserved. Mechanical repetition was reduced without padding or inventing missing material.

### Continuity preserved
- Ch61–63: ordinary work and companionship; no artificial death foreshadowing.
- Ch64: Vale's death.
- Ch65: official natural-causes conclusion.
- Ch66: Leon's first evidentiary doubt.
- Ch67–68: effects and grief through absence.
- Ch69: decision to enter deeper Constable work to understand Vale, not revenge.
- Ch70: observation/reasoning assessment, not combat.
- No new supernatural mechanism, Sign/Rank, or obsolete Keeper architecture.
- Case 3 is not reopened.

### Saved-file word counts

| Chapter | Words | Status |
|---|---:|---|
| 61 | 1773 | PASS |
| 62 | 1500 | PASS |
| 63 | 1663 | PASS |
| 64 | 1573 | PASS |
| 65 | 1751 | PASS |
| 66 | 1814 | PASS |
| 67 | 1556 | PASS |
| 68 | 1616 | PASS |
| 69 | 1586 | PASS |
| 70 | 1710 | PASS |

**Important:** Chapter 54 is not part of this batch and was not reconstructed.

The files are **READY FOR REVIEW**, not LOCKED.
