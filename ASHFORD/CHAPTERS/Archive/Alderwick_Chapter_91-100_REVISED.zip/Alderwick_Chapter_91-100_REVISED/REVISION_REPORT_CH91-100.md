# Alderwick — Chapter 91–100 Revision Report

Status: **REVISED / READY FOR REVIEW — NOT LOCKED**

## Revision scope

This pass preserves the examination arc and its core tasks while reducing explicit authorial explanation, repetitive lesson statements, and premature mystery confirmation. The major structural intervention is Chapter 96; Chapter 100 was tightened around professional authority and evidentiary limits.

## Chapter-by-chapter changes

- **Ch91 — The First Round:** strengthened the physical/judgment test, clarified the cost of helping Weaver, and reduced the explicit statement of what the office supposedly evaluated.
- **Ch92 — The Remaining:** expanded the rest-day/social observation function; reduced the recurring watching/lamp emphasis and made Hunter's question less like a repeated philosophical test.
- **Ch93 — The Second Round:** preserved teamwork and the slower route, but added a rational shift from low-risk choice to calculated moderate risk when circumstances changed. This prevents Leon from becoming mechanically “always choose the safest option.”
- **Ch94 — The Choice:** reduced repeated waiting/internal calculation and added physical/visual ambiguity around the two identical envelopes. The map remains useful information rather than an automatic “correct” answer.
- **Ch95 — The Third Round:** strengthened the practical difficulty of reaching the storehouse and made Hunter's assistance transactional rather than mentor-like. The ten-name list remains unexplained and is not treated as proof of a larger conspiracy.
- **Ch96 — The Division:** major canon/mystery-pacing correction. Aurelius Ashcroft's name remains part of the task, but Leon no longer explicitly confirms that the lock's symbol is the Agreement symbol or that the office is testing recognition of the Agreement. The clerk's reaction is kept ambiguous. Leon recognizes a resemblance without converting it into an answer.
- **Ch97 — The Hunt:** reduced post-action reconstruction. Leon identifies the route from a small number of observed fixed points rather than explaining the entire solution after the fact.
- **Ch98 — The Hunter:** preserved Hunter's competence and his imperfect judgment while keeping his internal reasoning partly opaque to Leon. This prevents Hunter from functioning as a hidden instructor.
- **Ch99 — The Last Twelve:** retained the three useful response patterns—over-trust, paralysis, and calibrated verification—while removing the explicit “lesson” statement.
- **Ch100 — The Final:** reframed Leon's final choice around evidence, provenance, and authority. He cannot verify either letter, cannot verify the sender, and has no established authority to alter the custody of the package. Therefore he preserves the package and reports it instead of treating uncertainty as a generic reason for caution. The ending now emphasizes beginning professional work rather than explaining the examination's lesson.

## Canon / continuity QA

- No `Keeper of Agreement` architecture introduced in Chapters 91–100.
- No `Thirteen Rings`, `Bloodhound`, `Covenant`, `Mr. Bell`, `Edmund Wren`, `00:00`, or Gear/Keeper's Door mechanics introduced.
- Case 3 is not reopened.
- Vale remains dead from Chapter 64 onward; these chapters do not alter that timeline.
- Leon remains outside the XIII Signs / Nine Ranks system; no Sign or Rank is assigned.
- The examination remains an assessment of observation, reasoning, physical judgment, social reading, uncertainty handling, and field decision-making—not a power progression.
- Ch96 no longer treats the resemblance of marks as proof of a direct Agreement connection.

## Word-count QA

Actual saved-file whitespace counts; every chapter meets the hard **1,500-word minimum**.

| Chapter | Words | Status |
|---|---:|---|
| 91 | 1,513 | PASS |
| 92 | 1,549 | PASS |
| 93 | 1,536 | PASS |
| 94 | 1,554 | PASS |
| 95 | 1,578 | PASS |
| 96 | 1,741 | PASS |
| 97 | 2,318 | PASS |
| 98 | 2,568 | PASS |
| 99 | 2,492 | PASS |
| 100 | 2,828 | PASS |
| **Total** | **19,677** | **PASS** |

## Review status

These files are **READY FOR REVIEW**, not LOCKED. They should replace the repository versions only after editorial approval. Originals are preserved separately in `Alderwick_Chapter_91-100_BACKUP`.
