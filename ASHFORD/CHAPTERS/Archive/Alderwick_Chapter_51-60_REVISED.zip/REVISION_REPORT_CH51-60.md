# Alderwick — Revision Report Chapters 51–60

**Status:** REVISED / READY FOR REVIEW — not LOCKED

## Revision direction
- Ch51–52: quiet Leon–Vale companionship; reduced lesson/exposition feel.
- Ch53: Greyhound closed epistemically; no reopening of Case 3.
- Ch55–57: Constable/archive work retained but made less lecture-like.
- Ch56: no death, illness, disappearance, farewell, or tragedy foreshadowing.
- Ch58–60: attachment built through ordinary routine, practical work, food, shared silence, and repeated weekly habits.
- No forced Bell/Door/Gear/00:00 material.
- No faction exposition dump.
- Minimum actual chapter length: 1,500 words.

## Saved-file word counts

| Chapter | Words | Status |
|---|---:|---|
| 51 | 1584 | PASS |
| 52 | 1735 | PASS |
| 53 | 2134 | PASS |
| 54 | — | PENDING |
| 55 | 2089 | PASS |
| 56 | 1671 | PASS |
| 57 | 1632 | PASS |
| 58 | 1604 | PASS |
| 59 | 1530 | PASS |
| 60 | 1503 | PASS |

## Chapter-level changes

- **Ch51 — The Second Afternoon:** preserved as companionship rather than formal Keeper transition; reduced map exposition; strengthened shared walking and practical familiarity.
- **Ch52 — The Window:** reduced overt physical-state emphasis; added a restrained exchange explaining Leon's willingness to help; kept repair and tea as the relationship core.
- **Ch53 — The Margin:** preserved Leon's self-audit of the Greyhound conclusion; tightened the missing-interval and physical-evidence discussion; finding remains “not proven.”
- **Ch55 — The Day-Book:** reduced abstract institutional explanation; retained the distinction between detailed reports and compressed office minutes.
- **Ch56 — The Settled Things:** made the archive sequence more procedural and less symbolic; kept the missing-paper anomaly documentary rather than supernatural.
- **Ch57 — The Disputed Debt:** reduced explicit methodological lecture; added the disputants' reactions so the investigation has human consequence.
- **Ch58 — The Thursday Walk:** strengthened ordinary companionship through collaborative gate repair and a small bakery/loaf exchange; no death foreshadowing.
- **Ch59 — The Paper Route:** softened the letter/Ferrand material; retained it as a quiet historical thread while strengthening routine through the recurring paper errand.
- **Ch60 — The Cup:** preserved the emotional payoff; kept the chipped cup, bread, knife sharpening, rain, and Thursday rhythm as concrete attachment markers.

## Chapter 54
The exact Chapter 54 manuscript was not available as a current file in the accessible uploaded-file set, and its earlier pasted text could not be recovered reliably enough to edit without inventing content. It is therefore intentionally left **PENDING** rather than reconstructed.

## Continuity
No new supernatural mechanism, Sign/Rank, faction membership, or premature Keeper architecture was introduced by this revision batch.

These files are **READY FOR REVIEW**, not LOCKED.
