# Alderwick — Revision Report Chapters 41–50

Status: **REVISED / READY FOR REVIEW** — not LOCKED.

## Main revision goals
- Align Chapters 41–50 with the current approved canon rather than the superseded draft architecture.
- Preserve the Order of Severence as the boundary/severance faction, while avoiding premature over-explanation.
- Keep Watchman and formal Keeper terminology distinct; formal Keeper status is not granted in these chapters.
- Keep Thomas Vale alive in this range; his death remains reserved for Chapter 64.
- Remove the duplicated Greyhound arc from Chapters 46–49; that case is not reopened.
- Avoid Gear, Door, 00:00, and Bellweather-house mystery mechanics from Chapter 46 onward.
- Strengthen Leon–Vale attachment through ordinary work, correction, routine, and companionship rather than repeated death foreshadowing.
- Preserve the Agreement's uncertainty and the distinction between evidence, inference, and hypothesis.
- Maintain the hard minimum of 1,500 actual saved-file words per chapter.

## Actual saved-file word counts

- Chapter 41: **1,775** words — PASS
- Chapter 42: **1,948** words — PASS
- Chapter 43: **1,885** words — PASS
- Chapter 44: **1,619** words — PASS
- Chapter 45: **1,671** words — PASS
- Chapter 46: **1,508** words — PASS
- Chapter 47: **1,504** words — PASS
- Chapter 48: **1,532** words — PASS
- Chapter 49: **1,500** words — PASS
- Chapter 50: **1,508** words — PASS

Independent count was performed on the saved revised files.
A second whitespace-based count was also checked during QA; every chapter remained above 1,500 words.

## Continuity QA

- No Miriam Vale, Mr. Bell, Edmund Wren, Bloodhound, Covenant, or 00:00 references detected.
- Formal Keeper title is not assigned in Chapters 41–50.
- Vale remains alive throughout this batch.
- The repeated Greyhound investigation from the uploaded draft has been removed from Chapters 46–49.
- The Agreement remains unresolved; differences between copies are treated as evidence requiring provenance analysis, not as proof of conspiracy.
- Order of Severence is introduced without collapsing every unknown actor into one organization.
- Chapters 46–50 focus on ordinary investigation, records, Order ambiguity, and Leon–Vale relationship development rather than reopening Case 3.
