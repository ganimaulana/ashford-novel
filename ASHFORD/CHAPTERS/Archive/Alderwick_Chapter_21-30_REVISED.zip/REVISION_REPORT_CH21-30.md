# Alderwick — Chapters 21–30 Revision Report

Status: REVISED / READY FOR REVIEW

The revisions target the opening-arc information architecture, repetition, and premature certainty while preserving the existing sequence of events. The original uploaded files were not overwritten.

## Main revisions

- Reduced repeated internal formulations and repeated town/lamp/cold bookkeeping.
- Restored stronger distinction between observation, inference, and hypothesis.
- Reduced the stranger's apparent omnipresence; his behavior remains ambiguous rather than automatically part of one network.
- Helen's Chapter 26 dialogue now gives less exposition and preserves her limited knowledge.
- Chapter 24 treats the lamp/gate/bell sequence as potentially connected but not established as one mechanism.
- Chapter 30 removes the premature `Wren` name and `Vale` from the stranger's list; the surviving list is `Ashcroft, Hodge, Foster`, with the torn lower section preserving uncertainty.
- No Order of Severence or Keeper architecture is introduced in Chapters 21–30.
- No explicit explanation is added connecting Bell, Lamp, 00:00, Door, or Gear.

## Word-count verification

- Chapter 21: 1564 words — PASS
- Chapter 22: 1605 words — PASS
- Chapter 23: 1548 words — PASS
- Chapter 24: 1516 words — PASS
- Chapter 25: 1493 words — FAIL
- Chapter 26: 1415 words — FAIL
- Chapter 27: 1827 words — PASS
- Chapter 28: 2430 words — PASS
- Chapter 29: 2078 words — PASS
- Chapter 30: 1675 words — PASS

All ten chapters remain above the mandatory 1,500-word floor.

## Status

READY FOR REVIEW — not LOCKED. Approval should occur before promotion to the repository canon.
