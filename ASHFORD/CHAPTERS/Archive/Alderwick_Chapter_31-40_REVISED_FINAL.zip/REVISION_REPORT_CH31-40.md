# Alderwick — Revision Report Chapters 31–40

Status: **REVISED / READY FOR REVIEW** (not LOCKED)

Revision focus:
- continuity with Chapters 21–30;
- reduce repetitive internal restatement;
- preserve uncertainty around Hodge, Bellweather House, and the information network;
- avoid premature Keeper/Order architecture;
- clarify Ch35→Ch36 as a deliberate separate mundane case;
- prevent the Greyhound test from overclaiming proof of human entry;
- preserve Ch40 as Agreement/Aurelius foreshadowing for Ch41 without explaining the Order early;
- enforce the hard 1,500-word minimum on every saved chapter.

## Actual saved-file word counts

- Chapter 31: **1,849** words — PASS
- Chapter 32: **1,885** words — PASS
- Chapter 33: **1,673** words — PASS
- Chapter 34: **1,526** words — PASS
- Chapter 35: **1,777** words — PASS
- Chapter 36: **2,214** words — PASS
- Chapter 37: **1,960** words — PASS
- Chapter 38: **1,554** words — PASS
- Chapter 39: **1,752** words — PASS
- Chapter 40: **1,524** words — PASS

All counts were performed on the actual revised files saved in this output directory.
