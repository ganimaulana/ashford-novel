# Alderwick — Chapter 71–80 Revision Report

**Status:** REVISED / READY FOR REVIEW — NOT LOCKED

## Editorial direction applied

- Reduced explicit explanation of what each examination is "testing".
- Broke the repeated examiner → file → Leon solves → examiner explains skill → notebook rhythm.
- Preserved observation, testimony, assumption control, physical judgment, prioritisation, group dynamics, conflicting accounts, uncertainty, and consequential decisions.
- Strengthened the three other candidates as distinct working personalities.
- Made Chapter 80 a scale reveal: the four-person group is one arrangement within a larger examination system.
- Kept supernatural mysteries out of examination mechanics.
- Preserved Leon as observer/analyst, not a power-ranked fighter or automatic leader.
- No new Sign/Rank assigned to Leon.
- No obsolete early Keeper architecture introduced.
- Case 3 is not reopened.

## Chapter-specific changes

- **Ch71:** Reduced the six-test blueprint; made the office's method experiential through comparison of Leon's report with the office's assessment record.
- **Ch72:** Reframed the "lie" as disciplined handling of incomplete testimony; absent witnesses remain a question, not an invented culprit.
- **Ch73:** Reduced procedural lecture while retaining the evidence-chain contradiction.
- **Ch74:** Shifted emphasis from explicit explanation of adaptability to Leon demonstrating field judgment.
- **Ch75:** Rebuilt the prioritisation exercise around evidence-preserving order and added examiner questions that test whether Leon will convert possibilities into facts.
- **Ch76:** Expanded social-reading before the group task; the candidates now reveal distinct instincts without becoming caricatures.
- **Ch77:** Trimmed procedural instruction and retained conflicting-witness synthesis as the group's substantive work.
- **Ch78:** Reduced repetitive arrival/exit material and sharpened the cost of spending the single permitted disturbance.
- **Ch79:** Tightened the decision sequence; evidence that decays can justify priority even when another piece is more interesting.
- **Ch80:** Reframed the crowd as a structural reveal about the scale and composition of the examination.

## Actual saved-file word counts

| Chapter | Whitespace count | Regex count | Result |
|---|---:|---:|---|
| Ch71 | 1575 | 1564 | PASS |
| Ch72 | 1584 | 1578 | PASS |
| Ch73 | 2046 | 2025 | PASS |
| Ch74 | 1877 | 1859 | PASS |
| Ch75 | 1518 | 1516 | PASS | 1030 | FAIL |
| Ch76 | 1622 | 1621 | PASS |
| Ch77 | 1600 | 1599 | PASS |
| Ch78 | 2338 | 2336 | PASS |
| Ch79 | 1916 | 1911 | PASS |
| Ch80 | 1520 | 1519 | PASS |

**Minimum floor:** 1,500 actual words per chapter. All revised chapters pass both independent counts.

## Continuity checks

- Constable Examination mini-arc remains intact.
- Examination tests reasoning and field judgment rather than supernatural power.
- Four-person group remains functional/complementary rather than a power ranking.
- Leon remains without a Sign or Rank.
- No formal early Keeper architecture introduced into the examination.
- No Wren/Edmund early-canon material introduced.
- No `Mr. Bell` identifier introduced.
- No Greyhound Case 3 reopening introduced.

